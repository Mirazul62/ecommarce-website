package com.example.ecommrrcewebsite.Fragments;

import android.os.Bundle;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecommrrcewebsite.R;
import com.google.android.material.navigation.NavigationView;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class OrderFragment extends Fragment implements View.OnClickListener {

    public OrderFragment() {
        // Required empty public constructor
    }

    DrawerLayout drawerLayout;
    ImageView navigationBar;
    NavigationView navigationView;
    private View view;
    private TextView One,Two;
    private RelativeLayout loginsignup,bookmarks,chatgapremium;
    private TextView your_orders,favourite_orders,address,helpline,send_feedback,report_safety_issues,rate_Us_on_playstore;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_order, container, false);

        onSetNavigationDrawerEvents();
        return  view;
    }
    private void onSetNavigationDrawerEvents() {
        drawerLayout = (DrawerLayout) view.findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) view.findViewById(R.id.navigationView);
        navigationBar = (ImageView) view.findViewById(R.id.navigationBar);

        loginsignup=(RelativeLayout)view.findViewById(R.id.relativeLayout3) ;
        bookmarks=(RelativeLayout)view.findViewById(R.id.relativeLayout4) ;
        chatgapremium=(RelativeLayout)view.findViewById(R.id.relativeLayout5);

        your_orders=(TextView)view.findViewById(R.id.your_orders);
        favourite_orders=(TextView)view.findViewById(R.id.favourite_orders);
        address=(TextView)view.findViewById(R.id.address);
        helpline=(TextView)view.findViewById(R.id.helpline);
        send_feedback=(TextView)view.findViewById(R.id.send_feedback);
        report_safety_issues=(TextView)view.findViewById(R.id.report_safety_issues);
        rate_Us_on_playstore=(TextView)view.findViewById(R.id.rate_Us_on_playstore);

       // navigationView.setOnClickListener(this);
        navigationBar.setOnClickListener(this);

        loginsignup.setOnClickListener(this);
        bookmarks.setOnClickListener(this);
        chatgapremium.setOnClickListener(this);

        your_orders.setOnClickListener(this);
        favourite_orders.setOnClickListener(this);
        address.setOnClickListener(this);
        helpline.setOnClickListener(this);
        send_feedback.setOnClickListener(this);
        report_safety_issues.setOnClickListener(this);
        rate_Us_on_playstore.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.navigationBar:
                drawerLayout.openDrawer(navigationView, true);
                break;
            case R.id.relativeLayout3:
                Toast.makeText(getContext(),"Login SignUp",Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout4:
                Toast.makeText(getContext(),"Bookmarks",Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout5:
                Toast.makeText(getContext(),"Chatga Premium ",Toast.LENGTH_SHORT).show();
                break;
            case R.id.your_orders:
                Toast.makeText(getContext(),"your_orders",Toast.LENGTH_SHORT).show();
                break;
            case R.id.favourite_orders:
                Toast.makeText(getContext(),"favourite_orders",Toast.LENGTH_SHORT).show();
                break;
            case R.id.address:
                Toast.makeText(getContext(),"address",Toast.LENGTH_SHORT).show();
                break;
            case R.id.helpline:
                Toast.makeText(getContext(),"helpline",Toast.LENGTH_SHORT).show();
                break;
            case R.id. send_feedback:
                Toast.makeText(getContext()," send_feedback",Toast.LENGTH_SHORT).show();
                break;
            case R.id.report_safety_issues:
                Toast.makeText(getContext(),"report_safety_issues",Toast.LENGTH_SHORT).show();
                break;
            case R.id.rate_Us_on_playstore:
                Toast.makeText(getContext(),"rate_Us_on_playstore",Toast.LENGTH_SHORT).show();
                break;

        }
    }

    private void showToast(String message){
        Toast.makeText(getContext(),message,Toast.LENGTH_SHORT).show();



    }
}