package com.example.ecommrrcewebsite.EmailLoginRegister;



    public class Constants {
        private static final String ROOT_URL ="http://192.168.1.11/Android/v1/";
        public static final String URL_REGISTER = ROOT_URL+"registerUser.php";
    }

