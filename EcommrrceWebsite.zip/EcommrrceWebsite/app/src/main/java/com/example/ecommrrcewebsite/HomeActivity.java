package com.example.ecommrrcewebsite;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        bottomNavigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        bottomNavigation.setOnNavigationItemSelectedListener(navigation);
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navigation =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    switch (item.getItemId())
                    {
                        case R.id.orders:
                            Toast.makeText(HomeActivity.this, "Orders", Toast.LENGTH_SHORT).show();
                            break;

                        case R.id.checkout:
                            Toast.makeText(HomeActivity.this, "Check Out", Toast.LENGTH_SHORT).show();
                            break;

                        case R.id.money:
                            Toast.makeText(HomeActivity.this, "Money", Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.videos:
                            Toast.makeText(HomeActivity.this, "Videos", Toast.LENGTH_SHORT).show();
                            break;
                    }


                    return true;
                }
            };
}