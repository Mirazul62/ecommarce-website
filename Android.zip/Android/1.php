<?php
require_once '../include/DbOperations.php';
$response = array();
if($_SERVER['REQUEST_METHOD'='POST'])
{
   if(isset($_post['email']) and isset($_post['password'])){
     $db=new DbOperations;
    if( $db->createUser($_post['email'],$_post['password']))
    {
        $response['error']=false;
        $response['message']="user registered successfully";
    }
    else
    {
        $response['error']=true;
        $response['message']="try again";
    }
   }
    else
    {
        $response['error']=true;
        $response['message']="required fields missing";
    }

}
else
{
   $response['error'] = true;
   $response['message']="Invalid Requset";

}
echo json_encode($response);