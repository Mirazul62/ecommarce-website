<?php
require_once '../includes/DbOperations.php';
$response = array();
if($_SERVER['REQUEST_METHOD'] = 'POST')
{
   if(isset($_POST['email']) and isset($_POST['password'])){
     $db=new DbOperations;
    if( $db->createUser($_POST['email'],$_POST['password']))
    {
        $response['error']=false;
        $response['message']="user registered successfully";
    }
    else
    {
        $response['error']=true;
        $response['message']="try again";
    }
   }
    else
    {
        $response['error']=true;
        $response['message']="required fields missing";
    }

}
else
{
   $response['error'] = true;
   $response['message']="Invalid Requset";

}
echo json_encode($response);