<?php
class DbOperations{
    private $con;
    function __construct(){
        require_once dirname(__FILE__).'/Dbconnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();
    }


    function createUser($email, $pass){
        $password=$pass;
        $stmt = $this->con->prepare("INSERT INTO `users` (`email`, `password`) VALUES ( ?, ? );");
        $stmt->bind_param("ss",$email,$password);
        if($stmt->execute())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}